package com.example.bus_track_app_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
